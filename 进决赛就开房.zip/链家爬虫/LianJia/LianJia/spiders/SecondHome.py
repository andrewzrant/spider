# -*- coding: utf-8 -*-
import scrapy
from bs4 import BeautifulSoup
from LianJia.items import LianjiaItem
import re

class SecondhomeSpider(scrapy.Spider):
    name = "SecondHome"
    def __init__(self,city="cs",category="二手房"):
        self.category = category #分类，默认二手房
        self.city = city  #城市，默认是长沙市

    def start_requests(self):
        """
        :function:爬虫的入口
        :return:
        """
        # 访问第1页到第100页的列表页
        for i in range(1, 101):
            url = "https://{0}.lianjia.com/ershoufang/pg{1}".format(self.city,i)
            print("**************", url, "**********************")
            yield scrapy.Request(url=url, callback=self.getList)  #访问第1页到第100页的列表页，每一页的返回结果传递到函数getList

    def getList(self, response):
        """
        :function：获取每一页的房子列表
        :param response:
        :return:
        """
        soup = BeautifulSoup(response.body, "lxml") #解析成BeautifulSoup
        #获取房子的url
        url_ls = soup.select(".clear.LOGCLICKDATA .title a")  #获取每个房子的详情页url列表
        if url_ls:
            #解析出每个房子的详情页
            for url in url_ls:
                title = ''.join(url.text.split())  #标题
                link = url["href"].strip()   #房子详情页链接
                id = link.split("/")[-1].replace(".html","")  #链家网房子的id
                item = LianjiaItem()  #加载一个item对象，进行装载爬取的字段
                item["dont_redirect"] = True  #禁止重定向
                item["handle_httpstatus_list"] = [301, 302]  # 防止重定向
                item["category"] = self.category
                item["id"] = id
                item["city"] = self.city
                item["list_url"] = link
                item["title"] = title
                yield scrapy.Request(url=link,callback=self.getInfo,meta = item)  #访问每个房子的详情页，每一页的返回结果传递到getInfo函数
        else:
            yield  None

    def getInfo(self,response):
        """
        :function：获得房源具体详情
        :param response:
        :return:
        """
        soup = BeautifulSoup(response.body, "lxml") #将html解析成BeautifulSoup
        item = response.meta #获取item
        try:
            price = soup.select(".price .total")[0].text #获取房价
            unit = soup.select(".price .unit")[0].text  #获取房间单元
            price = price + unit
        except:
            print("no price")
            price = "null"

        try:
            unitPrice = soup.select(".unitPriceValue")[0].text #获取单价
        except:
            print("no unitPrice")
            unitPrice = "null"

        #获取房源的基本属性
        baseInfo = soup.select(".base .label")
        try:
            if baseInfo:
                base_info_dict = {}  #房源基本属性用字典来装载
                for i in baseInfo:
                    key = i.text.strip()  #去空
                    value = i.next_sibling.strip() #去空
                    base_info_dict[key] = value
        except:
            print("no baseInfo")
            base_info_dict = "null"

        #获取房源的交易属性
        transaction = soup.select(".transaction .label")
        try:
            if transaction:
                trans_info_dict = {}  #房源交易属性用字典来装载
                for i in transaction:
                    key = i.text.strip()
                    value = i.next_sibling.next_sibling.get_text().strip()
                    trans_info_dict[key] = value
        except:
            trans_info_dict = "null"
            print("no trans_info_dict")
        # 解析出房源的基本属性

        #获取小区的名字和地理位置
        try:
            name = soup.select(".communityName .info")[0].text  #小区名称
        except:
            name = "null"
            print("no name")
        try:
            areaName = soup.select(".areaName .info")[0].text #区域名称
            areaName = "/".join(areaName.split())
        except:
            areaName = "null"
            print("no areaName")
        try:
            visitTime = soup.select(".visitTime .info")[0].text #看房时间
        except:
            visitTime = "null"
            print("no visitTime")
        try:
            brokerName = soup.select(".name.LOGCLICK")[0].text  #获取经济人的信息
        except:
            print("no brokerName")
            brokerName = "null"
        try:
            phone = soup.select(".phone")[0].text   #获取经纪人的手机号码
        except:
            print("no phone")
            phone = "null"

        #获取房源特色
        try:
            tags = soup.select(".tags.clear a")
            tags = list(map(lambda x:x.text,tags))
            tags = "/".join(tags)
        except:
            print("no tags")
            tags = "null"

        #房源其他信息
        ortherInfo = soup.select(".baseattribute.clear")
        other_info_dict = {} #房源其他信息用字典来装载
        try:
            for i in ortherInfo:
                key = i.select(".name")[0].text.strip()
                value = i.select(".content")[0].text.strip()
                other_info_dict[key] = value
        except:
            print("no other_info_dict")
            other_info_dict = "null"

        #户型图
        try:
            layout_pic = soup.find_all(name="img",attrs ={"alt":"户型图"})
            layout_pic = layout_pic[0]["src"]
        except:
            print("no layout_pic")
            layout_pic = "null"

        #方位信息
        layout_info = soup.select("#layoutList li")
        layout_ls = []
        try:
            for i in layout_info:
                layout = list(map(lambda x:x.text,i.select("span")))
                layout = "/".join(layout)
                layout_ls.append(layout)
            layout_ls = "$".join(layout_ls)
        except:
            print("no layout_pic")
            layout_pic = "null"

        item["name"] = name
        item["areaName"] = areaName
        item["visitTime"] = visitTime
        item["price"] = price
        item["unitPrice"] = unitPrice
        item["baseInfo"] = base_info_dict
        item["transaction"] = trans_info_dict
        item["brokerName"] = brokerName
        item["phone"] = phone
        item["tags"] = tags
        item["other_info_dict"] = other_info_dict
        item["layout_pic"] = layout_pic
        item["layout"] = layout_ls
        yield item













