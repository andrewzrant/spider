# -*- coding: utf-8 -*-

# Define here the models for your scraped items
#
# See documentation in:
# http://doc.scrapy.org/en/latest/topics/items.html

import scrapy


class LianjiaItem(scrapy.Item):
    city = scrapy.Field() #城市简称
    category = scrapy.Field() #类型，新房&二手房？
    list_url = scrapy.Field() #详情页url
    id = scrapy.Field() #房源ID
    title = scrapy.Field() #房源标题
    baseInfo = scrapy.Field() #房源基本信息
    transaction = scrapy.Field()  #交易属性
    name = scrapy.Field() #小区名
    areaName = scrapy.Field() #地区名
    visitTime = scrapy.Field() #看房时间
    brokerName = scrapy.Field() #经济人
    phone = scrapy.Field()#经济人联系方式
    tags = scrapy.Field() #房源标签
    other_info_dict = scrapy.Field() #其他信息
    layout = scrapy.Field() #房屋布局信息
    layout_pic = scrapy.Field() #布局图url
    price = scrapy.Field() #房价
    unitPrice = scrapy.Field() #单价
    dont_redirect = scrapy.Field() #防止重定向
    handle_httpstatus_list = scrapy.Field()






