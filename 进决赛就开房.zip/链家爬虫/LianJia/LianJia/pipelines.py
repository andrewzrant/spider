# -*- coding: utf-8 -*-

# Define your item pipelines here
#
# Don't forget to add your pipeline to the ITEM_PIPELINES setting
# See: http://doc.scrapy.org/en/latest/topics/item-pipeline.html

import csv
import os


class LianjiaPipeline(object):
# 保存为csv格式
    def open_spider(self, spider):
        city = spider.city
        self.f = open("./Data/rawData/myproject_{0}.csv".format(city),"a",newline="",encoding="utf-8",errors="ignored")
        # 设置文件第一行的字段名，注意要跟spider传过来的字典key名称相同
        self.fieldnames = [ 'id', 'category','title', 'list_url','name','city', 'areaName',
                            'price','unitPrice', 'baseInfo','transaction',
                            'brokerName', 'phone','visitTime','other_info_dict',
                            'layout', 'tags', 'layout_pic']
        # 指定文件的写入方式为csv字典写入，参数1为指定具体文件，参数2为指定字段名
        self.writer = csv.DictWriter(self.f, fieldnames=self.fieldnames,delimiter="|",quoting=csv.QUOTE_NONE)
        # 写入第一行字段名，因为只要写入一次，所以文件放在__init__里面
        self.writer.writeheader()

    def process_item(self, item, spider):
        # 写入spider传过来的具体数值
        temp_item = {k: v for k, v in item.items() if k in self.fieldnames}  # 过滤出fieldnames
        self.writer.writerow(temp_item)
        # 写入完返回
        return item

    def close(self,spider):
        self.f.close()
