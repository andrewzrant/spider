#!/usr/bin/env python
# coding: utf-8

# In[73]:


import pandas as pd
import numpy as np
import copy
import os


# In[ ]:

#解析字典数据
def parseDict(column,data):
    df = copy.deepcopy(data)
    keys_list = df[column].map(lambda x:list(eval(x).keys())).tolist()
    column_ls = []
    for i in keys_list:
        column_ls.extend(i)
    column_ls = sorted(list(set(column_ls)))
    if '' in column_ls:
        column_ls.remove("")
    dict_array =  df[column].map(lambda x:eval(x))
    
    parse_df = pd.DataFrame()
    for i in column_ls:
        parse_df[i] = dict_array.map(lambda x:x[i] if i in x.keys() else "null" )
    return parse_df


# In[80]:

#转换数据
def processData(file):
    data = pd.read_csv("./Data/rawData/"+file,sep="|")
    mainColumns = ['id', 'category', 'title', 'list_url', 'name', 'city', 'areaName',
       'price', 'unitPrice', 'brokerName', 'phone','visitTime', 'layout', 'tags', 'layout_pic']
    mainData = data[mainColumns]
    mainData.columns = ["id","分类","标题","url","小区名","城市","区域","价格","单价","经济人","经济人联系方式","看房时间","布局描述",
                   "房源特色","布局图"]
    baseInfo = parseDict("baseInfo",data)
    transaction = parseDict("transaction",data)
    result = pd.concat([mainData,baseInfo],axis=1)
    result = pd.concat([result,baseInfo],axis=1)
    result.to_csv("./Data/processData/"+file.replace(".csv","")+"_process"+".csv",index=False,sep="|")


# In[81]:


if __name__ == "__main__":
    raw_data_ls = list(filter(lambda x:".csv" in x,os.listdir("./Data/rawData/")))  #原始数据清单
    process_data_ls = list(filter(lambda x:".csv" in x,os.listdir("./Data/processData/"))) #已处理好的数据清单
    if process_data_ls:
        processed_ls = list(map(lambda x:x.replace("_process",""),process_data_ls))
        unprocessed_ls = list(set(raw_data_ls) - set(processed_ls)) #求还没有处理好的数据清单
    else:
        unprocessed_ls = raw_data_ls
    for i in unprocessed_ls:
        print(i)
        processData(i)


# In[ ]:




